import javax.swing.*;
import java.util.Scanner;
public class coilLesson03 {

    public static void main(String[] args) {

        Word[] words = new Word[5];
        System.out.println("わからなかった単語とその意味をスペースで区切って入力してください。");
        Scanner input = new Scanner(System.in);
        String inputs = input.nextLine();
        int i = 0;
        while (!"e".equals(inputs)) {
            String[] tmp = inputs.split(" |　");
            Word wd = new Word(tmp[0], tmp[1]);
           try {
               words[i] = wd;
           }
           catch(IndexOutOfBoundsException e){
               System.out.println("『登録制限を超えました。登録済みのデータは以下になります。』");
               break;
            }
            i++;
            System.out.println("次の単語と意味を入力してください。\"e\"で終了します。");
            inputs = input.nextLine();
        }
        for(int q=0;q <= i-1; q++){
            System.out.println(words[q]);
        }
        System.out.println(i + "件、登録しました");

    }}
