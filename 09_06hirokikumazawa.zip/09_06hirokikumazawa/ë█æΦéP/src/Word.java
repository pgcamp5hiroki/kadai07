public class Word {
    public String word;
    public String meaning;

public Word(String word,String meaning){
    this.word = word;
    this.meaning = meaning;
}

}
