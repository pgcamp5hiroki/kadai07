import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;
public class coilLesson04 {

    public static void main(String[] args) {
        ArrayList<Word>words = new ArrayList<>();
        System.out.println("わからなかった単語とその意味をスペースで区切って入力してください。");
        Scanner input = new Scanner(System.in);
        String inputs = input.nextLine();
        while (!"e".equals(inputs)) {
            String[] tmp = inputs.split(" |　");
            Word wd = new Word(tmp[0], tmp[1]);
            words.add(wd);
            System.out.println("次の単語と意味を入力してください。\"e\"で終了します。");
            inputs = input.nextLine();
        }
        for(int q=0;q <= words.size()-1; q++){
            System.out.println(words.get(q));
        }
        System.out.println(words.size() + "件、登録しました");

    }}
